# Lulu Guide

Site estático para um guia visual do jogo Lulu, pensado para publicação no GitHub Pages.

## Como publicar no GitHub Pages

1. Crie um repositório no GitHub, por exemplo `lulu-guide`.
2. Envie os arquivos `index.html`, `style.css`, `script.js` e `README.md` para a branch `main`.
3. No GitHub, acesse **Settings > Pages**.
4. Em **Build and deployment**, escolha:
   - Source: **Deploy from a branch**
   - Branch: **main**
   - Folder: **/root**
5. Salve e aguarde o GitHub gerar o link do site.

## O que editar

- Troque a ilustração do tabuleiro pelo tabuleiro real do Lulu.
- Ajuste as regras conforme a versão do jogo utilizada.
- Acrescente fotos autorizadas, fichas de registro e exemplos de respostas dos estudantes.
- Edite a paleta de cores no começo do arquivo `style.css`.

## Estrutura

```text
lulu-guide/
├── index.html
├── style.css
├── script.js
└── README.md
```

## Sugestão de seções futuras

- Galeria de tabuleiros
- Ficha de registro em PDF
- Variações do jogo
- Relatos de aplicação em sala
- Perguntas para discussão coletiva
