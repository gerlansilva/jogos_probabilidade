const menuButton = document.querySelector('.menu-button');
const menu = document.querySelector('#menu');
menuButton?.addEventListener('click', () => {
  const open = menu.classList.toggle('open');
  menuButton.setAttribute('aria-expanded', String(open));
});

document.querySelectorAll('#menu a').forEach(link => {
  link.addEventListener('click', () => {
    menu.classList.remove('open');
    menuButton?.setAttribute('aria-expanded', 'false');
  });
});

const rollButton = document.querySelector('#rollButton');
const result = document.querySelector('#result');
rollButton?.addEventListener('click', () => {
  const value = Math.floor(Math.random() * 6) + 1;
  result.textContent = `Resultado: ${value}`;
});
